﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Counter.BLL;
using Counter.Common;
using Counter.Common.Entity;

namespace Counter.Controllers
{
    public class CounterController : BaseController
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Post(CounterEntity entity)
        {
            MessageResult result = new MessageResult(string.Empty, false);
            CounterEntity newEntity = new CounterEntity();

            try
            {
                if (entity.Counter == 10)
                {
                    result.message = Constants.COUNTER_EXCEED_MAX_LENGTH;
                }

                CounterBLL bll = new CounterBLL();
                bll.Save(entity, "CurrentUser");

                result.data = CounterBLL.GetByID(entity.CounterID);
            }

            catch (Exception ex)
            {
                result.error = true;
                result.message = Constants.SERVER_ERROR;
            }

            return Json(result);
        }

        [HttpGet]
        public ActionResult Get(byte id)
        {
            MessageResult result = new MessageResult(string.Empty, false);
            CounterEntity userEntity = new CounterEntity();

            try
            {
                userEntity = CounterBLL.GetByID(id);

                if (userEntity == null)
                {
                    userEntity.CounterID = 0;
                    userEntity.Counter = 0;
                }

                result.data = userEntity;
            }

            catch (Exception ex)
            {
                result.error = true;
                result.message = Constants.SERVER_ERROR;
            }


            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Delete(byte id)
        {
            try
            {
                CounterBLL.Delete(id);
            }

            catch (Exception ex)
            {
            }

            return Json(0);
        }

        private bool ValidateNameIfExist(byte counter,
            byte id)
        {
            CounterBLL bll = new CounterBLL();

            return false;
        }
    }
}
