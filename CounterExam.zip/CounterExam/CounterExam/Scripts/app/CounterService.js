﻿/*
Name: Counter angular service
Dependencies:
*/
/// <reference path="CounterController.js" />
/// <reference path="../angular.js" />
(function () {

   var counter = function ($http) {

      var baseUrl = "/Counter/";

      var Get = function (id) {
          alert(id);
         return $http.get(baseUrl + "Get/" + id)
             .then(function (response) {
                //-- returns a promise and the data.
                return response.data;
             });
      };

      var Post = function (formData) {

         return $http({
            method: 'POST',
            url: baseUrl + "Post",
            data: formData,
            headers: { 'Content-Type': undefined }
         })
         .then(function (response) {
            //-- returns a promise and the data.
            return response.data;
         });
      };

      var Delete = function (id) {
         return $http({
            method: 'POST',
            url: baseUrl + "Delete/" + id,
            data: {},
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
         })
         .then(function (response) {
            //-- returns a promise and the data.
            return response.data;
         });
      };

      return {
         Get: Get,
         Post: Post,
         Delete: Delete
      };
   };


   //-- get the applicaiton (ng-app)
   var mainApp = angular.module("mainApp");

   //-- register messaging service in angular
   mainApp.factory("counter", counter);

}());