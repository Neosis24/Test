﻿/*
Name: Counter angular controller
Dependencies:
*/
/// <reference path="CounterService.js" />
/// <reference path="../angular.js" />
/// <reference path="../jquery.validate.js" />
/// <reference path="../jquery.js" />

(function () {

    var CounterController = function ($scope, counter) {

      var formName = "formCounter";

      var OnError = function (response) {
         alert("error: " + response);
      };

      var Get = function () {

         var OnGetSuccessful = function (data) {
            if (data.error) {
                alert(data.message);
               return;
            }

            $scope.counterID = data.data.CounterID;
            $scope.counter = data.data.Counter;
         };

          counter.Get($scope.counterID)
             .then(OnGetSuccessful, OnError);
      };

      var Post = function (event) {

         var OnSaveSuccessful = function (data) {

             if (data.error) {
                 alert(data.message);
                 return;
             }

             if (data.message != '') {
                 $scope.message = data.message;
             } else {
                 $scope.message = '';
                 $scope.counterID = data.data.CounterID;
                 $scope.counter = data.data.Counter;
             }
             

         };         

         var formData = new FormData(document.getElementById(formName));

         counter.Post(formData).then(OnSaveSuccessful, OnError);
      };

      var Reset = function (event) {

          $scope.message = '';
          $scope.counterID = 0;
          $scope.counter = 0;
      };

      var Init = function () {

          $form = angular.element("#" + formName);

          if ($scope.counterID == undefined) {
              $scope.counterID = 0;
              $scope.counter = 0;
          } else {
              Get($scope.counterID);
          }
      };

      $scope.Post = Post;
      $scope.Reset = Reset;

      //-- initialize
      (function () {
         Init();
      }());
   };

    //-- add new controller in the module
   angular.module('mainApp')
       .controller('CounterController', ['$scope',
           'counter',
           CounterController]);
}());


