﻿(function () {
    var mainApp = angular.module("mainApp",
           []
           );

    mainApp.run(["$rootScope", function ($rootScope) {


    }]);
}());