﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Counter.DAL
{
    public class BaseDataAccess: IDisposable
    {
        private const string DEFAULT_CONNECTION_NAME =
            "Default";

        private const string DEFAULT_TABLE =
            "Default";

        private SqlTransaction _transaction;
        private SqlConnection _connection;
        private Database _database;

        private bool _autoCommit = true;
        private bool _withTransaction = false;
        private bool _isCommitted = false;
        private bool _isRolledBack = false;

        protected int _count;

        private readonly ConnectionStringSettings _connectionString;

        protected BaseDataAccess(string connectionString)
        {
            _connectionString = new ConnectionStringSettings(
                DEFAULT_CONNECTION_NAME,
                connectionString);
        }

        protected BaseDataAccess(ConnectionStringSettings connectionString)
        {
            _connectionString = connectionString;
        }

        protected BaseDataAccess()
        {
        }


        /// <summary>
        /// Gets the database object.
        /// </summary>
        protected Database Database
        {
            get { return _database; }
        }

        /// <summary>
        /// Current executing command.
        /// </summary>
        protected virtual DbCommand CurrentCommand
        {
            get;
            private set;
        }

        protected BaseDataAccess(SqlTransaction transaction)
        {
            if (transaction == null)
            {
                throw new Exception("Transaction must not be null.");
            }

            _transaction = transaction;
            _withTransaction = true;
            _autoCommit = false;  //-- do not flush transaction in Dispose
        }

        protected ConnectionStringSettings ConnectionStringSettings
        {
            get
            {
                return _connectionString;
            }
        }

        /// <summary>
        /// Get the value of the output parameter
        /// </summary>
        /// <param name="parameterName">Name of the parameter. Its best to prepend @ in the parameter name ex: @Count.</param>
        /// <returns>value of the parameter. Null if none.</returns>
        protected object GetParameterValue(string parameterName)
        {
            return Database.GetParameterValue(CurrentCommand, parameterName);
        }

        protected string ConnectionString
        {
            get
            {
                return _connectionString.ConnectionString;
            }
        }

        protected virtual string TableName
        {
            get
            {
                return string.Empty;
            }
        }

        #region > List Interfaces


        #region > List Public Properties

        /// <summary>
        /// Automatically commit when the object is disposed.
        /// </summary>
        public bool AutoCommit
        {
            get { return _autoCommit; }
            set { _autoCommit = value; }
        }

        #endregion


        #endregion


        #region > Transaction Management


        #region > Properties

        public SqlTransaction Transaction
        {
            get
            {
                return _transaction;
            }
        }

        /// <summary>
        /// Check if the data access is using transaction
        /// </summary>
        public bool WithTransaction
        {
            get
            {
                return _withTransaction;
            }
        }

        #endregion


        #region > Methods

        public void BeginTransaction()
        {
            InitializeTransaction(IsolationLevel.ReadCommitted);//-- default isolation level
        }

        public void BeginTransaction(IsolationLevel isolationLevel)
        {
            InitializeTransaction(isolationLevel);
        }

        protected void InitializeTransaction(IsolationLevel isolationLevel)
        {
            //-- allow not to reinitalize transaction that already exist
            if (_transaction == null)
            {
                if (_connection == null ||
                    _connection.State == ConnectionState.Closed)
                {
                    _connection = new SqlConnection(ConnectionString);
                    _connection.Open();
                }

                _transaction = _connection.BeginTransaction(isolationLevel);
                _withTransaction = true;
            }
        }

        public virtual void CommitTransaction()
        {
            if (_withTransaction &&
                _transaction != null &&
                !_isCommitted &&
                !_isRolledBack)
            {
                _transaction.Commit();
                _isCommitted = true;
            }
        }

        public virtual void RollBackTransaction()
        {
            if (_withTransaction &&
                _transaction != null &&
                !_isCommitted &&
                !_isRolledBack)
            {
                _transaction.Rollback();
                _isRolledBack = true;
            }
        }

        #endregion


        #endregion


        #region IDisposable Members

        public virtual void Dispose()
        {
            if (_transaction != null && _autoCommit)
            {
                //auto commit
                CommitTransaction();
                _transaction.Dispose();
            }

            if (_connection != null)
            {
                if (_connection.State == ConnectionState.Open)
                {
                    _connection.Close();
                }

                _connection.Dispose();
            }
        }

        #endregion
    }
}
