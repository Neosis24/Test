﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Counter.Common.Entity;
using Microsoft.ApplicationBlocks.Data;

namespace Counter.DAL
{
    public class CounterDAL: BaseDataAccess
    {
        #region > Constants

        private const string _commandInsert =
            "CounterInsert";

        private const string _commandUpdate =
            "CounterUpdate";

        private const string _commandDelete =
            "CounterDelete";

        private string _commandSelectByID =
            "CounterSelectByID";

        #endregion

        #region > Constructors

        public CounterDAL(ConnectionStringSettings connectionStringSettings)
            : base(connectionStringSettings)
        {

        }

        #endregion

        #region > Enumerations

        public enum Column
        {
            CounterID,
            Counter
        }

        #endregion

        #region > CRUD

        public byte Insert(CounterEntity data)
        {
            object retVal = SqlHelper.ExecuteScalar(
                    ConnectionString,
                    _commandInsert,
                    data.Counter);

            data.CounterID = Convert.ToByte(retVal.ToString());

            return data.CounterID;
        }

        public void Update(CounterEntity data)
        {
            object retVal = SqlHelper.ExecuteScalar(
                    ConnectionString,
                    _commandUpdate,
                    data.CounterID,
                    data.Counter);
        }

        public void Delete(int counterID)
        {
            SqlHelper.ExecuteNonQuery(
                    ConnectionString,
                    _commandDelete,
                    counterID);
        }

        #endregion

        #region > Select

        public CounterEntity SelectByID(int id)
        {
            using (IDataReader reader = SqlHelper.ExecuteReader(
                    ConnectionString,
                    _commandSelectByID,
                    id))
            {
                return ProcessRow(reader);
            }
        }

        #endregion

        private static CounterEntity ProcessRow(IDataReader reader)
        {
            if (!reader.Read())
            {
                return null;
            }

            return new CounterEntity(
                reader.GetByte((int)Column.CounterID),
                reader.GetByte((int)Column.Counter));
        }
    }
}
