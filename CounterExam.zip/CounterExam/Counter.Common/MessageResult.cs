﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Counter.Common
{
    public class MessageResult
    {
        public object data;
        public bool error;
        public string message;

        public MessageResult(string message, bool error)
        {
            this.message = message;
            this.error = error;
        }

        public MessageResult(string message, bool error, object data)
        {
            this.message = message;
            this.error = error;
            this.data = data;

        }
    }
}
