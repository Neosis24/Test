﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Counter.Common
{
    public static class Constants
    {
        public static string SERVER_ERROR
        {
            get
            {
                return "Server error. Please contact administrator.";
            }
        }

        #region Counter

        public const string COUNTER_EXCEED_MAX_LENGTH = "Counter should not able to increase beyond 10.";

        #endregion
    }
}
