﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Counter.Common.Entity
{
    [Serializable]
    public class CounterEntity
    {
        #region > Variables

        private byte _counterID;
        private byte _counter;

        #endregion

        #region > Constructors

        public CounterEntity() 
        {
        
        }

        public CounterEntity(byte CounterID,
            byte Counter) 
        {
            _counterID = CounterID;
            _counter = Counter;
        
        }

        #endregion

        #region > Properties

        public byte CounterID
        {
            get
            {
                return _counterID;
            }

            set
            {
                 _counterID = value;
            }
        }

        public byte Counter
        {
            get
            {
                return _counter;
            }

            set
            {
                 _counter = value;
            }
        }

        #endregion
    }
}
