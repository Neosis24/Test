﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Counter.Common
{
    public enum EnumPermission
    {
        None = 1,    
        Add = 2,     
        Edit = 3,    
        Delete = 4
    }

    public class Enums
    {
    }
}
