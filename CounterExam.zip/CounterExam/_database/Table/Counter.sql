
USE [PracticeDB]
GO

IF EXISTS (SELECT * FROM dbo.sysobjects
    WHERE id = object_id(N'[dbo].[CounterInsert]')
    and OBJECTPROPERTY(id, N'IsProcedure') = 1)

    DROP PROCEDURE [dbo].[CounterInsert]

GO

CREATE PROC [dbo].[CounterInsert]
    @Counter TINYINT
AS

    INSERT INTO [Counter]
         (
        [Counter]
        )
     VALUES
         (
        @Counter
        )

         SELECT IDENT_CURRENT('Counter')


GO

IF EXISTS (SELECT * FROM dbo.sysobjects
    WHERE id = object_id(N'[dbo].[CounterUpdate]')
    and OBJECTPROPERTY(id, N'IsProcedure') = 1)

    DROP PROCEDURE [dbo].[CounterUpdate]

GO

CREATE PROC [dbo].[CounterUpdate]
    @CounterID TINYINT,
    @Counter TINYINT
AS

    UPDATE [Counter] SET
        [Counter] = @Counter
     WHERE [CounterID] = @CounterID

GO


IF EXISTS (SELECT * FROM dbo.sysobjects
    WHERE id = object_id(N'[dbo].[CounterDelete]')
    and OBJECTPROPERTY(id, N'IsProcedure') = 1)

    DROP PROCEDURE [dbo].[CounterDelete]

GO

CREATE PROC [dbo].[CounterDelete]
    @CounterID TINYINT
AS

    SET NOCOUNT ON

    DELETE FROM [Counter]
        WHERE [CounterID] = @CounterID

    SET NOCOUNT OFF


GO

IF EXISTS (SELECT * FROM dbo.sysobjects
    WHERE id = object_id(N'[dbo].[CounterSelectByID]')
    and OBJECTPROPERTY(id, N'IsProcedure') = 1)

    DROP PROCEDURE [dbo].[CounterSelectByID]

GO

CREATE PROC [dbo].[CounterSelectByID]
    @CounterID TINYINT
AS

    SET NOCOUNT ON

    SELECT [CounterID]
      ,[Counter]
    FROM [Counter]
        WHERE [CounterID] = @CounterID

    SET NOCOUNT OFF

GO
