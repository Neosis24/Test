
/* Create "PracticeDB" database.                                                                */
use master  

go

create database "PracticeDB"  

go

use "PracticeDB"  

go

                                                  
create table "Counter" ( 
	"CounterID" tinyint identity not null,
	"Counter" tinyint not null)  

go

alter table "Counter"
	add constraint "Counter_PK" primary key ("CounterID")   


go

