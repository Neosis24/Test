I used Visual Studio 2012 and SQL Server 2012

Step on creating database

1. Run PracticeDB.sql
2. Run Table/Counter.sql

Step on Running the Website
1. Edit the Web.Config and update the connectionString. See example below.
Example:
  <connectionStrings>
    <add name="Default" providerName="System.Data.SqlClient" connectionString="Server=CTI102314107\SQLEXPRESS2012;Database=PracticeDB;Integrated Security=SSPI;" />
  </connectionStrings>
2. Change the Server name. Base on your SQL Server.
3. Open the solution on Visual Studio. The solution name is "CounterExam".

System Structure
1. From Database - There are SQL file need to be run, base on the step above.
2. I used layering approach:

WebUI ----- BLL ----- DAL
  |          |         |
  -----------------------
             |
          Common (Act as Mobile Object)

3. I used Angularjs on client scripting.
4. I created javascript files per module. Example(CounterController.js and CounterService.js).



