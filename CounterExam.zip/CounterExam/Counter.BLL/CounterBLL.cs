﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Counter.Common;
using Counter.Common.Entity;
using Counter.DAL;

namespace Counter.BLL
{
    public class CounterBLL : BaseBusinessLogic
    {
        public static CounterEntity GetByID(int id)
        {
            using (CounterDAL dal = new CounterDAL(GetConnectionInfo()))
            {
                return dal.SelectByID(id);
            }
        }

        #region > Crud

        public int Save(CounterEntity data, String currentUser)
        {
            using (CounterDAL dal = new CounterDAL(GetConnectionInfo()))

                try
                {
                    if (IsEditMode(data.CounterID))
                    {
                        data.Counter++;
                        dal.Update(data);
                    }
                    else
                    {
                        data.Counter++;
                        dal.Insert(data);
                    }

                    return data.CounterID;
                }

                catch (Exception ex)
                {
                    throw ex;
                }

                finally
                {
                    dal.Dispose();
                }
        }

        public static void Delete(byte counterID)
        {
            using (CounterDAL dal = new CounterDAL(GetConnectionInfo()))
            {
                try
                {
                    dal.Delete(counterID);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    dal.Dispose();
                }
            }
        }

        #endregion
    }
}
