﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Counter.BLL
{
    public abstract class BaseBusinessLogic
    {

        protected static ConnectionStringSettings GetConnectionInfo()
        {
            ConnectionStringSettings connectionInfo =
                ConfigurationManager.ConnectionStrings["Default"];

            if (connectionInfo == null)
            {
                throw new ApplicationException(
                    "Please specify default connection string in the application configuration file.");
            }

            return connectionInfo;
        }

        /// <summary>
        /// Check if the the view is in edit mode.
        /// </summary>
        public static bool IsEditMode(object value)
        {
            if (value is byte || value is byte)
            {
                return Convert.ToByte(value) > 0;
            }

            return value != null;
        }

    }
}
